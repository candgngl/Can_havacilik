﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Can_Havacilik
{
    public class Yolcu
    {
        internal object sehir;
        internal object ulke;

        public Guid ID { get; set; }
        public string Adi { get; set; }
        public string Soyadi { get; set; }
        public string Tel { get; set; }
        public string Mail { get; set; }
        public string Cinsiyet { get; set; }
        public string Pasaport { get; set; }
        public string Ad { get; internal set; }
        public object HavalimaniAdi { get; internal set; }
        public object PasaportBilgi { get; internal set; }
        public object Soyad { get; internal set; }
        public object Telefon { get; internal set; }

        public override string ToString()
        {
            return $"{Adi} {Soyadi}";
        }
    }

    public class Ucus
    {
        public Guid ID { get; set; }
        public DateTime Kalkis_saat { get; set; }
        public string Varis_noktasi { get; set; }
        public string Havayolu_sirketi { get; set; }
        public string Kalkis_noktasi { get; set; }
        public DateTime İnis_saati { get; set; }
        public override string ToString()
        {
            return $"{Kalkis_noktasi} {Varis_noktasi}";
        }
    }

    public class Bilet
    {
        public Guid ID { get; set; }
        public Ucak Ucak_bilgisi { get; set; }
        public Yolcu Yolcular { get; set; }
        public double Bilet_fiyati { get; set; }
        public string Yolcu_Ad { get; set; }
        public string Koltuk_Numarasi { get; set; }
        public override string ToString()
        {
            return $"{Bilet_fiyati} {Yolcular}";
        }
    }

    public class Ucak
    {
        public Guid ID { get; set; }
        public Yolcu Yolcular { get; set; }
        public string Sehir { get; set; }
        public string Ülke { get; set; }
        public string Havalimanı_adi { get; set; }
        public object HavalimaniAdi { get; internal set; }
        public object Ulke { get; internal set; }
    }
}