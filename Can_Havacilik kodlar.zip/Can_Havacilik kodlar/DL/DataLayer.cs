﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Can_Havacilik.DL
{
    public static class DataLayer
    {
        public static int YolcuEkle(Yolcu m)
        {
            using (SqlConnection conn = new SqlConnection(
                new SqlConnectionStringBuilder()
                {
                    DataSource = "192.168.1.156",
                    InitialCatalog = "Can_Havacilik",
                    IntegratedSecurity = true
                }.ConnectionString))
            {
                try
                {
                    conn.Open();
                    SqlCommand komut = new SqlCommand("can_YolcularHepsi", conn);
                    komut.CommandType = CommandType.StoredProcedure;
                    komut.Parameters.AddWithValue("@id", m.ID);
                    komut.Parameters.AddWithValue("@ad", m.Ad);
                    komut.Parameters.AddWithValue("@soyad", m.Soyad);
                    komut.Parameters.AddWithValue("@tel", m.Telefon);
                    komut.Parameters.AddWithValue("@mail", m.Mail);
                    komut.Parameters.AddWithValue("@pasaportBilgi", m.PasaportBilgi); // Düzeltme: PasaportBilgi düzeltildi
                    komut.Parameters.AddWithValue("@cinsiyet", m.Cinsiyet);

                    int res = komut.ExecuteNonQuery();
                    return res;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata oluştu: " + ex.Message);
                    return -1;
                }
            }
        }

        internal static int YolcuGuncelle(object yolcu, Yolcu m)
        {
            throw new NotImplementedException();
        }

        internal static DataSet YolcuGetir(string filtre)
        {
            throw new NotImplementedException();
        }

        public static int YolcuSil(string iD)
        {
            using (SqlConnection conn = new SqlConnection(
                new SqlConnectionStringBuilder()
                {
                    DataSource = "192.168.1.156",
                    InitialCatalog = "Can_Havacilik",
                    IntegratedSecurity = true
                }.ConnectionString))
            {
                try
                {
                    conn.Open();
                    SqlCommand komut = new SqlCommand("can_yolcuSil", conn);
                    komut.CommandType = CommandType.StoredProcedure;
                    komut.Parameters.AddWithValue("@id", iD);

                    int res = komut.ExecuteNonQuery();
                    return res;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata oluştu: " + ex.Message);
                    return -1;
                }
            }
        }

        public static int UcakEkle(Ucak u)
        {
            using (SqlConnection conn = new SqlConnection(
                new SqlConnectionStringBuilder()
                {
                    DataSource = "192.168.1.156",
                    InitialCatalog = "Can_Havacilik",
                    IntegratedSecurity = true
                }.ConnectionString))
            {
                try
                {
                    conn.Open();
                    SqlCommand komut = new SqlCommand("can_UcakEkle", conn);
                    komut.CommandType = CommandType.StoredProcedure;
                    komut.Parameters.AddWithValue("@id", u.ID);
                    komut.Parameters.AddWithValue("@havalimaniAdi", u.HavalimaniAdi);
                    komut.Parameters.AddWithValue("@ulke", u.Ulke);
                    komut.Parameters.AddWithValue("@sehir", u.Sehir);

                    int res = komut.ExecuteNonQuery();
                    return res;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata oluştu: " + ex.Message);
                    return -1;
                }
            }
        }

        internal static int HavalimaniSil(object ıD)
        {
            throw new NotImplementedException();
        }

        

        internal static int UcakGuncelle(Ucak u)
        {
            throw new NotImplementedException();
        }

        public static DataSet UcakGetir(string filtre = "")
        {
            using (SqlConnection conn = new SqlConnection(
                new SqlConnectionStringBuilder()
                {
                    DataSource = "192.168.1.156",
                    InitialCatalog = "Can_Havacilik",
                    IntegratedSecurity = true
                }.ConnectionString))
            {
                try
                {
                    conn.Open();
                    SqlCommand komut = new SqlCommand("can_UcaklarHepsi", conn);
                    komut.CommandType = CommandType.StoredProcedure;

                    DataSet dataSet = new DataSet();
                    SqlDataAdapter adp = new SqlDataAdapter(komut);
                    adp.Fill(dataSet);
                    return dataSet;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata oluştu: " + ex.Message);
                    return null;
                }
            }
        }
    }
}
