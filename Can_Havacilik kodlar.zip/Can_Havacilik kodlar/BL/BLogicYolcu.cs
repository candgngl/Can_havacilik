﻿using Can_Havacilik.DL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Can_Havacilik.BL
{
    public static class BLogicYolcu2
    {
        private static object yolcu;
        private static object ex;

        public static object ID { get; private set; }

        public static bool YolcuEkle(Yolcu m)
        {
            try
            {

                int res = DataLayer.YolcuEkle(m);

                return (res > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata oluştu : " + ex.Message);
                return false;
            }

        }

        internal static DataSet YolcuGetir1(string Filtre)
        {
            try
            {

                DataSet ds = DataLayer.YolcuGetir(Filtre);

                return ds;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata oluştu : " + ex.Message);
                return null;
            }

        }

        internal static bool YolcuGuncelle(Yolcu m)
        {
            try
            {

                int res = DataLayer.YolcuGuncelle(yolcu, m);

                return (res > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata oluştu : " + ex.Message);
                return false;
            }
        }

        internal static bool HavalimanıSil(string iD)
        {
            try
            {
                int res = DataLayer.YolcuSil(iD);
                return (res > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata oluştu: " + ex.Message);
                return false;
            }
        }

        internal static bool UcakEkle1(Ucak u)
        {
            try
            {

                int res = DataLayer.UcakEkle(u);

                return (res > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata oluştu : " + ex.Message);
                return false;
            }
        }

        internal static DataSet UcakGetir1(string filtre)
        {
            try
            {

                DataSet ds = DataLayer.UcakGetir(filtre);

                return ds;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata oluştu : " + ex.Message);
                return null;
            }
        }

        internal static bool UcakEkle(object ucak)
        {
            throw new NotImplementedException();
        }

        internal static bool UcakGuncelle1(Ucak u)
        {
            try
            {

                int res = DataLayer.UcakGuncelle(u);

                return (res > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata oluştu : " + ex.Message);
                return false;
            }
            
            {

            
            }

        }
    }
}