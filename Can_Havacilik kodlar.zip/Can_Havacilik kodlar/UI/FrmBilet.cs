﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Can_Havacilik.UI
{
    public partial class FrmBilet : Form
    {
        public FrmBilet()
        {
            InitializeComponent();

        }
        public Yolcu Yolcular { get; set; }
        public Ucak Ucak_bilgisi { get; set; }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if(nmFiyat.Value == 0)
            {
                errorProvider1.SetError(nmFiyat, "Lütfen Fiyat Giriniz");
                nmFiyat.Focus();
                return;

            }
            else
            {
                errorProvider1.SetError(nmFiyat, "");
            }
            DialogResult = DialogResult.OK;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
       }
      private void FrmBilet_Load(object sender , EventArgs e)
        {
           

            txtYolcuadi.Text = Yolcular.ToString();
            txtUcakbilgisi.Text = Yolcular.ToString();
        }

    }
}
