﻿
namespace Can_Havacilik.UI
{
    partial class AnaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnYolcuEkle = new System.Windows.Forms.ToolStripButton();
            this.btnYolcuDüzenle = new System.Windows.Forms.ToolStripButton();
            this.btnYolcuSil = new System.Windows.Forms.ToolStripButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.btnYolcuBul = new System.Windows.Forms.ToolStripButton();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.btnUcakEkle = new System.Windows.Forms.ToolStripButton();
            this.btnUcakDuzenle = new System.Windows.Forms.ToolStripButton();
            this.btnUcakSil = new System.Windows.Forms.ToolStripButton();
            this.btnUcakAra = new System.Windows.Forms.ToolStripLabel();
            this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.statusStrip2 = new System.Windows.Forms.StatusStrip();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(536, 450);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.toolStrip1);
            this.tabPage1.Controls.Add(this.statusStrip1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(528, 421);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Yolcular";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tabControl2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(528, 421);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Ucak";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Location = new System.Drawing.Point(3, 396);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(522, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip1_ItemClicked);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnYolcuEkle,
            this.btnYolcuDüzenle,
            this.btnYolcuSil,
            this.toolStripLabel1,
            this.toolStripTextBox1,
            this.btnYolcuBul});
            this.toolStrip1.Location = new System.Drawing.Point(3, 3);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(522, 27);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // btnYolcuEkle
            // 
            this.btnYolcuEkle.Image = global::Can_Havacilik.Properties.Resources.Sample_User_Icon;
            this.btnYolcuEkle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYolcuEkle.Name = "btnYolcuEkle";
            this.btnYolcuEkle.Size = new System.Drawing.Size(60, 24);
            this.btnYolcuEkle.Text = "Ekle";
            this.btnYolcuEkle.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // btnYolcuDüzenle
            // 
            this.btnYolcuDüzenle.Image = global::Can_Havacilik.Properties.Resources.edit;
            this.btnYolcuDüzenle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYolcuDüzenle.Name = "btnYolcuDüzenle";
            this.btnYolcuDüzenle.Size = new System.Drawing.Size(87, 24);
            this.btnYolcuDüzenle.Text = "Düzenle";
            this.btnYolcuDüzenle.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // btnYolcuSil
            // 
            this.btnYolcuSil.Image = global::Can_Havacilik.Properties.Resources.delete_icon_png_16x16_21;
            this.btnYolcuSil.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYolcuSil.Name = "btnYolcuSil";
            this.btnYolcuSil.Size = new System.Drawing.Size(49, 24);
            this.btnYolcuSil.Text = "Sil";
            this.btnYolcuSil.Click += new System.EventHandler(this.btnYolcuSil_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 30);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(522, 366);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(32, 24);
            this.toolStripLabel1.Text = "Ara";
            this.toolStripLabel1.Click += new System.EventHandler(this.toolStripLabel1_Click);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 27);
            this.toolStripTextBox1.Click += new System.EventHandler(this.toolStripTextBox1_Click);
            // 
            // btnYolcuBul
            // 
            this.btnYolcuBul.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnYolcuBul.Enabled = false;
            this.btnYolcuBul.Image = global::Can_Havacilik.Properties.Resources.find;
            this.btnYolcuBul.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYolcuBul.Name = "btnYolcuBul";
            this.btnYolcuBul.Size = new System.Drawing.Size(29, 24);
            this.btnYolcuBul.Text = "toolStripButton1";
            this.btnYolcuBul.Click += new System.EventHandler(this.toolStripButton1_Click_1);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 30);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(508, 331);
            this.dataGridView2.TabIndex = 2;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(522, 415);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView2);
            this.tabPage3.Controls.Add(this.toolStrip2);
            this.tabPage3.Controls.Add(this.statusStrip2);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(514, 386);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Yolcular";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // toolStrip2
            // 
            this.toolStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnUcakEkle,
            this.btnUcakDuzenle,
            this.btnUcakSil,
            this.btnUcakAra,
            this.toolStripTextBox2});
            this.toolStrip2.Location = new System.Drawing.Point(3, 3);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(508, 27);
            this.toolStrip2.TabIndex = 1;
            this.toolStrip2.Text = "toolStrip1";
            // 
            // btnUcakEkle
            // 
            this.btnUcakEkle.Image = global::Can_Havacilik.Properties.Resources.Airport_add;
            this.btnUcakEkle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnUcakEkle.Name = "btnUcakEkle";
            this.btnUcakEkle.Size = new System.Drawing.Size(60, 24);
            this.btnUcakEkle.Text = "Ekle";
            // 
            // btnUcakDuzenle
            // 
            this.btnUcakDuzenle.Image = global::Can_Havacilik.Properties.Resources.edit_2;
            this.btnUcakDuzenle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnUcakDuzenle.Name = "btnUcakDuzenle";
            this.btnUcakDuzenle.Size = new System.Drawing.Size(87, 24);
            this.btnUcakDuzenle.Text = "Düzenle";
            // 
            // btnUcakSil
            // 
            this.btnUcakSil.Image = global::Can_Havacilik.Properties.Resources.delete_2;
            this.btnUcakSil.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnUcakSil.Name = "btnUcakSil";
            this.btnUcakSil.Size = new System.Drawing.Size(49, 24);
            this.btnUcakSil.Text = "Sil";
            // 
            // btnUcakAra
            // 
            this.btnUcakAra.Image = global::Can_Havacilik.Properties.Resources.search_2;
            this.btnUcakAra.Name = "btnUcakAra";
            this.btnUcakAra.Size = new System.Drawing.Size(52, 24);
            this.btnUcakAra.Text = "Ara";
            // 
            // toolStripTextBox2
            // 
            this.toolStripTextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox2.Name = "toolStripTextBox2";
            this.toolStripTextBox2.Size = new System.Drawing.Size(100, 27);
            // 
            // statusStrip2
            // 
            this.statusStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip2.Location = new System.Drawing.Point(3, 361);
            this.statusStrip2.Name = "statusStrip2";
            this.statusStrip2.Size = new System.Drawing.Size(508, 22);
            this.statusStrip2.TabIndex = 0;
            this.statusStrip2.Text = "statusStrip1";
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(792, 421);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Ucak";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // AnaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(536, 450);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "AnaForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Can_Havacilik";
            this.Load += new System.EventHandler(this.AnaForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnYolcuEkle;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripButton btnYolcuDüzenle;
        private System.Windows.Forms.ToolStripButton btnYolcuSil;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripButton btnYolcuBul;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton btnUcakEkle;
        private System.Windows.Forms.ToolStripButton btnUcakDuzenle;
        private System.Windows.Forms.ToolStripButton btnUcakSil;
        private System.Windows.Forms.ToolStripLabel btnUcakAra;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
        private System.Windows.Forms.StatusStrip statusStrip2;
        private System.Windows.Forms.TabPage tabPage4;
    }
}