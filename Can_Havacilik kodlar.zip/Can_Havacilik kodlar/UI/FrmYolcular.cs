﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Can_Havacilik.UI
{
    public partial class FrmYolcular : Form
    {
        public FrmYolcular()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        public Yolcu Yolcular { get; set; }
        public bool Güncelleme { get; set; } = false;

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (!ErrorControl(txtAdi)) return;
            if (!ErrorControl(txtSoyadi)) return;
            if (!ErrorControl(txtTel)) return;
            if (!ErrorControl(txtMail)) return;
            if (!ErrorControl(txtCinsiyet)) return;
            if (!ErrorControl(txtPasaport)) return;
            ErrorControl(txtSoyadi);

            Yolcular.Adi = txtAdi.Text;
            Yolcular.Soyadi = txtSoyadi.Text;
            Yolcular.Tel = txtTel.Text;
            Yolcular.Mail = txtMail.Text;
            Yolcular.Cinsiyet = txtCinsiyet.Text;
            Yolcular.Pasaport = txtPasaport.Text;

            if (txtPasaport.Text == "")
            {
                errorProvider1.SetError(txtPasaport, "Eksik Veya Hatalı Bilgi");
                txtPasaport.Focus();
                return;
            }
            else
            {
                errorProvider1.SetError(txtPasaport, "");
            }

            DialogResult = DialogResult.OK;
        }

        private bool ErrorControl(Control c)
        {
            if (c is TextBox)
            {
                if (c.Text == "")
                {
                    errorProvider1.SetError(c, "Eksik Veya Hatalı Bilgi Girdiniz");
                    c.Focus();
                    return false;
                }
                else
                {
                    errorProvider1.SetError(c, "");
                    return true;
                }
            }
            if (c is MaskedTextBox)
            {
                if (!((MaskedTextBox)c).MaskFull)
                {
                    errorProvider1.SetError(c, "Eksik Veya Hatalı Bilgi Girdiniz");
                    c.Focus();
                    return false;
                }
                else
                {
                    errorProvider1.SetError(c, "");
                    return true;
                }
            }

            return true;
        }

        private void FrmYolcular_Load(object sender, EventArgs e)
        {
            txtID.Text = Yolcular.ID.ToString();
            if (Güncelleme)
            {
                txtAdi.Text = Yolcular.Adi;
                txtSoyadi.Text = Yolcular.Soyadi;
                txtTel.Text = Yolcular.Tel;
                txtMail.Text = Yolcular.Mail;
                txtCinsiyet.Text = Yolcular.Cinsiyet;
                txtPasaport.Text = Yolcular.Pasaport;
            }
                 
        }
    }
}
