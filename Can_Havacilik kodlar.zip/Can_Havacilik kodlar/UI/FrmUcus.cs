﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Can_Havacilik.UI
{
    public partial class FrmUcus : Form
    {
        public FrmUcus()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
           

        private void btnOk_Click(object sender, EventArgs e)
        {

            if (!ErrorControl(txtKalkis)) return;
            if (!ErrorControl(txtKalkisnoktasi)) return;
            if (!ErrorControl(txtVaris)) return;
            if (!ErrorControl(txtKalkisnoktasi)) return;
            if (!ErrorControl(txtİnis)) return;

            


            if (cbHavayolu2.SelectedItem == null)

            {
                errorProvider1.SetError(cbHavayolu2, "Havayolu Sirketini Seçiniz");
                cbHavayolu2.Focus();
                return;

            }
            else
            {
                errorProvider1.SetError(cbHavayolu2, "");

            }

            DialogResult = DialogResult.OK;
        }
        private bool ErrorControl(Control c)
        {
            if (c is TextBox || c is ComboBox)
            {

                if (c.Text == "")
                {
                    errorProvider1.SetError(c, "Eksik Veya Hatalı Bilgi Girdiniz");
                    c.Focus();
                    return false;
                }
                else
                {
                    errorProvider1.SetError(c, "");
                    return true;
                }

            }
            return true;
        }
    }
}