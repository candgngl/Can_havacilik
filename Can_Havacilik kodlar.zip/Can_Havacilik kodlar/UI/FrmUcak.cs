﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Can_Havacilik.UI
{
    public partial class FrmUcak : Form
    {
        public FrmUcak()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
        public Ucak ucak_bilgisi { get; set; }

        public bool Güncelleme { get; set; } = false;
        public object Ucak { get; internal set; }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (cbHavalimaniAdi.SelectedItem == null)
            {
             
                errorProvider1.SetError(cbHavalimaniAdi, "Havalimanınızı Seçiniz");
                cbHavalimaniAdi.Focus();
                return;
            
            }
            else
            {
                errorProvider1.SetError(cbHavalimaniAdi, "");
            
            }
       


            DialogResult = DialogResult.OK;
        
        }

        private void FrmUcak_Load(object sender, EventArgs e)
        {
            if(Güncelleme)
            {
                txtID.Text = ucak_bilgisi.ID.ToString();
                if (Güncelleme)
                {

                }
            }
        }
    }
}
